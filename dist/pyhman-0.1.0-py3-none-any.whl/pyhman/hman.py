import socket
import logging
import struct

class Hman:
    HMAN_PORT = 5000

    def __init__(self, nb_mot, verbose):
        self.nb_mot = nb_mot
        self.verbose = verbose
        self.pkgSize = 2 + nb_mot * 8
        self.mode = None
        self.cmd = bytearray(self.pkgSize)
        self.client = None
        self.positions = [0, 0, 0]#encoder positions
        self.target_positions = [0, 0, 0]
        self.target_currents = [0, 0, 0]
        #enum of possible modes
        self.modes = {
            'position': 0,
            'current': 1,
            'velocity': 2,
            'impedance': 3
        }

        logging.basicConfig(level=logging.DEBUG if verbose else logging.INFO)
        logging.info('Initialised.')

    def __del__(self):
        if self.client:
            self.client.close()
        logging.info('Disconnected.')

    def connect(self, address):
        logging.info('Connecting to %s:%d...', address, self.HMAN_PORT)
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.client.connect((address, self.HMAN_PORT))
        except socket.error as exc:
            logging.error(f'Caught exception socket.error : {exc}')

    def set_mode(self, mode):
        #check if the mode is valid
        if mode not in self.modes:
            logging.error('Invalid mode.')
            return
        logging.info('Setting mode to %s', mode)
        self.mode = mode
        self.cmd[0] = ord('M')
        self.cmd[2:6] = struct.pack('>i', self.modes[mode])
        self.client.sendall(self.cmd)

    def __set_values(self, val, n):
        self.cmd[0] = ord('V')
        self.cmd[1] = self.nb_mot
        logging.debug('Setting values to %s', val)

        for i in range(n):
            self.cmd[2 + i * 4 : 2 + (i + 1) * 4] = struct.pack('>i', val[i])
        self.client.sendall(self.cmd)
        # wait for the response
        data = self.client.recv(self.nb_mot * 4)
        if not data:
            logging.error('No data received.')
            return
        self.positions = [struct.unpack('>i', data[i*4 : (i+1)*4])[0] for i in range(self.nb_mot)]#encoder positions
        return self.positions
        

    def set_cartesian_pos(self, posx, posy, posz):
        if self.mode != 'position':
            self.set_mode('position')

        pos = [-posx + posy, -posx - posy, posz]
        self.target_positions = pos
        self.__set_values(pos, 3)
        #transform the cartesian articular position to cartesian position
        return [(self.positions[0] + self.positions[1]) / 2, (-self.positions[0] + self.positions[1]) / 2, self.positions[2]]

    def set_articular_pos(self, pos1, pos2, pos3):
        if self.mode != 'position':
            self.set_mode('position')

        pos = [pos1, pos2, pos3]
        self.target_positions = pos
        self.__set_values(pos, 3)
        return self.positions

    def set_motors_current(self, cur1, cur2, cur3):
        if self.mode != 'current':
            self.set_mode('current')

        curr = [cur1, cur2, cur3]
        self.target_currents = curr
        self.__set_values(curr, 3)
        return self.positions

    def turn_off_current(self):
        if self.mode != 'current':
            self.set_mode('current')

        cur = [0] * self.nb_mot
        self.__set_values(cur, self.nb_mot)

    def get_pos(self):
        self.cmd[0] = ord('P')
        self.cmd[1] = self.nb_mot
        self.client.sendall(self.cmd)

        response = self.client.recv(self.nb_mot * 4)
        self.positions = [struct.unpack('>i', response[i*4 : (i+1)*4])[0] for i in range(self.nb_mot)]#encoder positions
        return self.positions
    
#create a hman object
hman = Hman(3, True)
#connect to the hman
hman.connect('127.0.0.1')
#set the motors in position mode
hman.set_mode('position')
#set the motors in articular position
pos = hman.set_articular_pos(0, 40, 30)
print(pos)